# switchfix

Fix text typed in the wrong keyboard layout (EN↔RU) — Linux/KDE tray utility.

```
switchfix daemon     # tray + hotkeys + corrections (default)
switchfix settings   # settings window
switchfix doctor     # diagnostics
switchfix setup      # group 'input' + udev rule
switchfix selftest   # inject ctrl+f20 via uinput, verify evdev intercept
```

Needs membership in group `input` for global hotkeys / uinput.
Prefer the .deb package when possible (installs maps, desktop file,
systemd user unit and udev rule).
