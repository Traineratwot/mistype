# mistype

Fix text typed in the wrong keyboard layout (EN↔RU) — Linux/KDE tray utility.

```
mistype daemon     # tray + hotkeys + corrections (default)
mistype settings   # settings window
mistype doctor     # diagnostics
mistype setup      # group 'input' + udev rule
mistype selftest   # inject ctrl+f20 via uinput, verify evdev intercept
```

Needs membership in group `input` for global hotkeys / uinput.
Prefer the .deb package when possible (installs maps, desktop file,
systemd user unit and udev rule).
